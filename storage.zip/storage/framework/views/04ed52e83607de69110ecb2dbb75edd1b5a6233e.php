<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            color: #333;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
            background-color: white;
            color: black;
            position: fixed;
            width: 100%;
            top: 0;
            left: 0;
            z-index: 1000;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .navbar .logo {
            font-family: 'Pacifico', cursive;
            font-size: 1.5em;
        }

        .navbar .menu {
            display: flex;
            align-items: center;
        }

        .navbar .menu a {
            color: black;
            text-decoration: none;
            margin-left: 20px;
            font-size: 1em;
        }

        .navbar .menu a:hover {
            text-decoration: underline;
        }

        .container {
            max-width: 1400px;
            margin: 100px auto 20px;
            padding: 20px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .order-list {
            list-style: none;
            padding: 0;
        }

        .order-item {
            padding: 15px;
            border-bottom: 1px solid #ddd;
        }

        .order-item:last-child {
            border-bottom: none;
        }

        .order-item h3 {
            margin: 0 0 10px;
        }

        .order-item p {
            margin: 5px 0;
        }
    </style>
</head>

<body>
    <div class="navbar">
        <div class="logo">Z-collection</div>
        <div class="menu">
            <a href="<?php echo e(route('products.index')); ?>" class="products">Products</a>
            <a href="<?php echo e(route('cart.get')); ?>" class="cart"><i class="fa fa-shopping-cart"></i> <span class="badge">2</span></a>
            <a href="<?php echo e(route('orders.myOrders')); ?>" class="orders"><i class="fa fa-box"></i> Orders</a>
            <a href="#" class="logout">Logout</a>
        </div>
    </div>
    <div class="container">
        <h1>My Orders</h1>
        <ul class="order-list">
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="order-item">
                <h3>Order #<?php echo e($order->id); ?></h3>
                <p>Date: <?php echo e($order->created_at->format('d M Y')); ?></p>
                <p>Total: Rp <?php echo e(number_format($order->total, 0, ',', '.')); ?></p>
                <p>Status: <?php echo e($order->status); ?></p>
                <!-- Tambahkan detail pesanan lainnya sesuai kebutuhan -->
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <script>
        $(document).ready(function() {
            $('.logout').click(function(event) {
                event.preventDefault(); // Mencegah aksi default dari link
                window.location.href = '/'; // Ganti '/' dengan URL halaman utama Anda
            });
        });
    </script>
</body>

</html><?php /**PATH C:\Users\Akira\OneDrive\Documents\zulffaya_c\resources\views/orders/myOrders.blade.php ENDPATH**/ ?>